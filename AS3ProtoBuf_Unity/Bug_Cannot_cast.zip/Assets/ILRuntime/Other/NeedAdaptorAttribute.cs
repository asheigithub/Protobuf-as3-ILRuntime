﻿namespace ILRuntime.Other
{
    /// <summary>
    /// A Class Custom Attr, It tells the CodeGenerationTools :there is a class need to generate an adaptor for ILScript
    /// </summary>
    public class NeedAdaptorAttribute : System.Attribute
    {

    }
}
